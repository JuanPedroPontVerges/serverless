import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='juanpedro',
    application_name='my-serverless-proyect',
    app_uid='RmFkfy5B4D6nmRsC6s',
    org_uid='6c48344e-4644-4887-a164-9d3109beba2b',
    deployment_uid='a516e16a-1eb7-4385-a44a-cdc005d51814',
    service_name='my-serverless-proyect',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.4.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'my-serverless-proyect-dev-webapi', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('webapi.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
